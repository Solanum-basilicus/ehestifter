# ATS Discovery Phase 9 critical review

## Scope reviewed

- milestone Phase 9 acceptance and the deferred final product rename;
- integration of stable ATS Discovery architecture into `docs/system-design.md`;
- archival of the active milestone source;
- root and component documentation accuracy;
- Compose, package, provenance, scheduler, test, CI, and path naming;
- ignored local configuration, secrets, catalogs, state, backups, and run artifacts;
- installed systemd path/service coupling;
- active scheduler-state path migration;
- upstream attribution and historical evidence;
- migration preflight, idempotency/fail-closed behavior, rollback, and validation;
- preservation of domain ownership and completed Phase 6/7 behavior.

## Accepted decisions

### Phase 9 includes the deferred product rename

The milestone explicitly made the rename a pre-merge cleanup requirement. Documentation-only edits would leave the active directory, Compose service, image, package, provenance, scheduler config, tests, and operator commands under the bootstrap name. Phase 9 therefore completes both documentation integration and active product naming.

### Guarded migration instead of a complete scanner overlay

The scanner directory contains important ignored operator state. A complete replacement archive could silently omit or overwrite:

- `scanner.local.json` and `scheduler.local.json`;
- customized Compose configuration;
- machine-managed catalogs;
- tenant and scheduler state;
- state backups;
- secrets;
- run evidence.

The package moves the complete directory first, then rewrites active text outside `data/` and `secrets/`. This preserves local operational content and file ownership.

### Installed systemd units must be removed before rename

Phase 7 renders the scanner root and Compose command into system-level units. Leaving old units installed would make the next activation fail against a missing working directory/service. The migration fails closed when matching installed or active units exist; the apply guide requires uninstall before rename and reinstallation after validation.

### Active state paths are migrated; historical evidence is not

Only active `scheduler-state.json` path strings are updated, and only after writing a timestamped backup. Logical slot, completion/degraded outcome, and timestamps are not fabricated or reset.

`data/runs`, backup history, and already-created jobs/canaries retain former provenance/path values as historical evidence. Rewriting them would create false history and break artifact hashes/comparisons.

### Tracked repository references are updated outside the scanner

A scanner-local replacement is insufficient if CI, root scripts, `.gitignore`, or active docs call the old path/service. In a real Git checkout, the migration enumerates tracked files for external reference updates. Untracked local files outside the scanner are not modified. Historical `docs/archive/` content and package staging are excluded.

### Upstream name and product name remain distinct

`career-ops-scan` is the former Ehestifter product identifier and is replaced in active product surfaces. `Career-Ops` / `santifer/career-ops` remains source attribution and is deliberately preserved. job-board-aggregator catalog attribution and license records also remain.

### Phase-specific records remain historical evidence

The new component README is canonical for steady-state operation. Existing `README-PHASE*.md` files remain implementation evidence and receive only the mechanical active product token update. The milestone is moved to `docs/archive/milestones/ats-discovery.md` and clearly marked historical.

### Optional Phase 8 remains skipped

No Cloud Run Job design is invented during cleanup. Local Docker plus systemd is the documented steady-state runtime. A cloud run-to-completion deployment needs a separate measured milestone and durable-state decision.

## Findings corrected during review

1. **Blind extraction would lose ignored operational content.** Replaced with a complete directory move followed by bounded active-text rewriting.
2. **A directory rename alone would leave installed units broken.** Added installed/active systemd fail-closed preflight and mandatory uninstall/reinstall procedure.
3. **A scanner-only token replacement could leave CI/root references stale.** Added tracked repository reference rewriting and synthetic CI validation.
4. **A repository-wide filesystem replacement could alter untracked virtual environments and local notes.** Real Git mode now limits external changes to tracked files; fallback mode excludes common generated/local directories.
5. **Historical run/provenance rewriting would falsify evidence.** Excluded all scanner `data/` and archived docs; added byte-preservation tests.
6. **Active scheduler state can contain absolute old paths.** Added recursive path-only migration with a timestamped backup and outcome-preservation test.
7. **Local scheduler config is ignored but operationally authoritative.** The moved active scanner tree is rewritten in place, so `compose.service` follows the new service without replacing operator policy.
8. **The first validator pass looked for unformatted milestone metadata.** Corrected it to recognize the actual Markdown `**Status:** archived` form.
9. **Payload compilation initially created mutable `__pycache__` files inside checksum scope.** Excluded generated bytecode from the payload manifest and final archive.
10. **A validator necessarily contains the legacy token as a detection constant.** Excluded the validator itself from its active-reference scan while preserving all target checks.
11. **The old root README described scrapers/Synapse as future architecture.** Replaced it with the current Azure/GCP/local topology and ATS Discovery entry points.
12. **The master system design explicitly said scrapers were inactive.** Integrated provider/catalog, multi-user, Jobs/Enrichment, artifact/state, scheduler, attribution, and limitation sections and removed stale exclusions.
13. **The upstream copy helper could still appear to be an update mechanism.** Added an idempotent bootstrap-only warning without replacing the attributed source logic.
14. **A second migration attempt could merge or duplicate trees.** The script fails closed when the old source is absent or the destination already exists.
15. **Payload corruption could produce partial application.** All complete payload files are SHA-256 verified before repository mutation.

## Validation performed on review infrastructure

- Python compilation of migration, validator, and package tests: passed.
- Seven migration/package tests: passed.
- Dry-run non-mutation: passed.
- Full rename and payload installation: passed.
- Git-mode tracked CI rewrite with untracked-note preservation: passed.
- Ignored secrets/catalog and historical run byte preservation: passed.
- Active scheduler-state path migration and backup with unchanged outcome: passed.
- Payload SHA-256 validation: passed.
- Second-application fail-closed behavior: passed.
- Post-apply repository layout validator: passed inside each successful migration fixture.

The complete Ehestifter checkout was not available to the execution container, so the existing 355-test scanner suite and 27-test Phase 7 scheduler suite could not be rerun here. They remain mandatory executor validation before commit.

## Known limitations accepted

### Git rename presentation is heuristic

The migration uses a filesystem move because it must carry ignored files. Git will report delete/add pairs until it detects/stages renames based on similarity. This does not lose history, but the executor must inspect `git diff --find-renames`.

### Semantic variants beyond the exact product token are not blindly rewritten

The migration replaces `career-ops-scan` exactly. It does not globally replace every phrase containing “Career-Ops,” because many are required upstream attribution. The new canonical docs establish the correct product language; remaining ambiguous prose should be reviewed in the real repository diff.

### Historical archive references remain intentionally stale-looking

The archived milestone records the former implementation path and planning state. The archive header explicitly distinguishes history from current architecture. Validators exclude `docs/archive/` from active naming checks.

### No automatic rollback after repository mutation

An automatic rollback could overwrite ignored local state or conceal a partial validation issue. The script fails with actionable output and leaves the complete moved tree in place for inspection. APPLY.md provides explicit rollback steps and warns against `git clean -fdx`.

### Systemd behavior is not exercised in the package container

No host systemd installation, Docker daemon, real timers, or reboot/resume path was available. The installer and scheduler suites plus operator render/install/canary checks remain authoritative.

### Full scanner behavior is intentionally unchanged, not reimplemented

Phase 9 relies on mechanical identity changes and canonical documentation. It does not modify provider protocols, matching defaults, Jobs reconciliation, detail/location normalization, compatibility scheduling, or logical-slot algorithms.

### The active branch name may remain historical

`feature/career-ops-scan` is a Git branch name and can remain until merge/delete. Product code, service, paths, docs, and new provenance use ATS Discovery. No branch rename is required for runtime correctness.

## Boundary review

- No Jobs, Users, Enrichment, Analytics, or other product-domain database writes were added.
- No cross-domain endpoint contract was changed by the migration.
- Users discovery-eligible behavior remains owned by Users.
- Jobs canonical identity and shared job creation remain authoritative.
- Enrichment Core compatibility lifecycle remains authoritative.
- ATS Discovery still creates no application status.
- No provider request, filtering, catalog planning, canary, health, import, or compatibility algorithm was changed.
- Scheduler logical-slot, retry, lock, degraded exit, state backup, and retention behavior was not changed.
- Active scanner state remains local operational metadata.
- Existing source attribution and non-commercial catalog constraints remain visible.
