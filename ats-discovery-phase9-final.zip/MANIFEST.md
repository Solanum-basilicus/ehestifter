# ATS Discovery Phase 9 manifest

This archive is extracted at the Ehestifter repository root. It contains a guarded migration plus complete reviewed payload files; it is not a direct overlay of the scanner tree.

The migration moves the complete existing scanner directory so ignored operator configuration, catalogs, state, backups, runs, and secrets are preserved. It intentionally does not package active local config, secrets, catalogs, scheduler/tenant state, locks, backups, or run artifacts.

| Path | Purpose | SHA-256 |
|---|---|---|
| `APPLY.md` | Repository-root preflight, migration, validation, systemd reinstall, commit, and rollback instructions. | `aa2cfd41aabf78acdca6d6303a6b8b95dc45863cfb521ba9db8d4453b168348c` |
| `CRITICAL-REVIEW.md` | Mandatory design/operational review, corrected findings, limitations, and boundary verification. | `acccb560c112fb7ea6f9fd8278881cb50cd883ee4572b4f3c2db8a7c85c9ae42` |
| `SOURCES.md` | Ehestifter, upstream attribution, issue, Git, Docker Compose, and systemd source references. | `774244883d7aaad75d40667ece6a29d287d70d72f2627c12bb10becc8f0adb88` |
| `TEST-RECORD.md` | Review-environment commands, seven-test result, coverage, and mandatory executor validation. | `df32cea68423f765394290e24995e6006b96cd0e09869310e7b5b976413dcc77` |
| `apply_phase9.py` | Guarded standard-library migration preserving ignored state while renaming active product surfaces. | `6f5ec7b9e1e16b004095577e2295dfe0350c2bfd968e069e02d21edcae78f538` |
| `phase9-payload/README.md` | Complete replacement root README reflecting the current Azure/GCP/local system. | `0325520257b0aede70a54ac7e2de40c2f69c0acef340ee8063a6234a6ad3e7b6` |
| `phase9-payload/docs/archive/milestones/ats-discovery.md` | Complete archived milestone with preserved history and final phase/acceptance outcome. | `3cbee56f8909d3592d3363455866e6ab70acfdcb0ab64ef9eb5fce17dd6451b1` |
| `phase9-payload/docs/system-design.md` | Complete replacement master architecture with ATS Discovery integrated as implemented. | `0749f4f159e33946599a2bad99fd21ac1ee1a9c7fe08ad303467720a33eaf441` |
| `phase9-payload/payload-manifest.json` | Machine-readable SHA-256 map verified by the migration before repository mutation. | `67fccc8afca2fc18b36d41ffdd06366ca228da309d37e13da01f5320b02d01b4` |
| `phase9-payload/scrapers/ats-discovery/README.md` | Canonical scanner architecture, configuration, operations, scheduling, tests, and limitations. | `aadf32111e7e5d067f5f8af2f11b1130d20011df7d155ae7464236f8afa5612f` |
| `phase9-payload/tools/validate_ats_discovery_layout.py` | Permanent post-migration repository layout and active naming validator. | `d988c051e6fa08285ce49e2789892e32f0c4fdf0a9ec56b48debab28bbaf78fe` |
| `phase9-tests/test_apply_phase9.py` | Synthetic filesystem/Git migration, preservation, state-backup, checksum, and fail-closed tests. | `245d0092d422fcf30356eb7a51949a9b624b01845dd857594a6dacdbe5f39079` |

Files excluding this manifest: **12**.

Complete payload destinations installed by `apply_phase9.py`:

```text
README.md
docs/system-design.md
docs/archive/milestones/ats-discovery.md
scrapers/ats-discovery/README.md
tools/validate_ats_discovery_layout.py
```

The active `docs/milestone_ats_discovery.md` is removed after the archived document is installed. Other active references containing the exact former product token are rewritten only within the moved scanner tree and, in a Git checkout, tracked repository files. Historical `docs/archive/` and scanner `data/` content are not rewritten.
