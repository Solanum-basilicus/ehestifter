# Apply ATS Discovery Phase 9

This archive is applied at the Ehestifter repository root on branch `feature/career-ops-scan` after Phase 7 commit `9f8452c8e1e8dbe5a778abb090da9c28a110890f` is present in history.

Phase 9 is a guarded migration, not a blind overlay. It:

- moves the complete `scrapers/career-ops-scan` directory to `scrapers/ats-discovery` so ignored local files move with it;
- changes active product references from `career-ops-scan` to `ats-discovery` in the scanner and tracked repository files;
- updates active local scheduler config when present;
- migrates path strings in active scheduler state after creating a timestamped backup;
- preserves `data/runs`, catalogs, tenant state, backups, secrets, and historical job/run provenance;
- installs the canonical root README, system design, scanner README, archived milestone, and layout validator;
- removes the active `docs/milestone_ats_discovery.md` after installing its archived successor;
- marks the upstream provider copy helper as bootstrap-only.

It does not change provider, matching, Jobs, import, compatibility, or scheduler algorithms.

## 1. Confirm baseline and clean tracked work

From the repository root:

```bash
git switch feature/career-ops-scan
git status --short
git log -1 --oneline
git merge-base --is-ancestor \
  9f8452c8e1e8dbe5a778abb090da9c28a110890f \
  HEAD
```

The final command must exit `0`. Commit or stash tracked changes before continuing. Untracked archive files are allowed by the migration preflight.

Optional but recommended local backup before a path migration:

```bash
backup_dir="$HOME/ehestifter-phase9-backup-$(date -u +%Y%m%dT%H%M%SZ)"
mkdir -p "$backup_dir"
cp -a --reflink=auto \
  scrapers/career-ops-scan \
  "$backup_dir/"
printf 'Local scanner backup: %s\n' "$backup_dir"
```

This can be large because it intentionally includes ignored catalogs, state, runs, and secrets. Store it outside the repository and protect it as a secret-bearing backup.

## 2. Stop and uninstall old rendered systemd units

Installed Phase 7 service files contain the old `WorkingDirectory` and Compose service. They must not survive the rename.

First inspect active work:

```bash
systemctl status ehestifter-ats-discovery.service --no-pager || true
systemctl status ehestifter-ats-catalog-refresh.service --no-pager || true
./scrapers/career-ops-scan/ops/scheduler/ats-ops status || true
```

Allow a legitimate scan to finish, or intentionally stop it. Then stop timers/services and uninstall the old units:

```bash
sudo systemctl stop \
  ehestifter-ats-discovery.timer \
  ehestifter-ats-catalog-refresh.timer \
  ehestifter-ats-discovery.service \
  ehestifter-ats-catalog-refresh.service \
  2>/dev/null || true

sudo python3 \
  scrapers/career-ops-scan/ops/systemd/install_systemd.py \
  uninstall
```

Confirm no old units remain:

```bash
find /etc/systemd/system /usr/local/lib/systemd/system \
  -maxdepth 1 \
  -name 'ehestifter-ats-*' \
  -print 2>/dev/null
```

The migration fails closed when matching installed or active units are detected.

## 3. Extract and inspect the package

Extract the archive at repository root:

```bash
unzip -o ats-discovery-phase9-final.zip -d .
```

Inspect package contents and hashes:

```bash
sed -n '1,240p' MANIFEST.md
cat phase9-payload/payload-manifest.json
python3 -m compileall -q \
  apply_phase9.py \
  phase9-payload/tools \
  phase9-tests
```

`apply_phase9.py` verifies every payload SHA-256 before touching the repository.

## 4. Run the non-mutating preflight

```bash
python3 apply_phase9.py --dry-run
```

The dry run verifies:

- the payload checksums;
- a clean tracked tree;
- the Phase 7 commit ancestry;
- absence of active/installed old scheduler units;
- required Phase 7 scanner files;
- absence of a conflicting `scrapers/ats-discovery` directory.

Do not use `--allow-unverified-head`, `--allow-dirty`, or `--skip-systemd-check` in the normal repository flow. Those switches exist for exceptional/manual recovery and package tests.

## 5. Apply the migration

```bash
python3 apply_phase9.py
```

Expected high-level output:

```text
Moved scrapers/career-ops-scan -> scrapers/ats-discovery
Rewrote ... scanner paths/files.
Rewrote ... active repository references outside the scanner.
Marked copy-upstream-providers.sh as bootstrap-only.
Migrated active scheduler-state path strings ...   # only when needed
Installed 5 payload files.
Removed active milestone file: docs/milestone_ats_discovery.md
ATS Discovery layout validation passed.
Phase 9 migration and post-apply layout validation completed.
```

The scanner directory move preserves ignored content. Active text rewriting excludes `data/`, `secrets/`, `node_modules/`, generated caches, and historical `docs/archive/` content. In a Git checkout, active references outside the scanner are limited to tracked files.

If `data/state/scheduler-state.json` contains the old absolute/relative scanner path, the script writes a backup named like:

```text
data/state/scheduler-state.phase9-pre-rename.20260726T123456Z.json
```

It changes path strings only; slot/outcome timestamps and status values are preserved.

## 6. Review the resulting diff and layout

```bash
git status --short
git diff --stat
git diff --summary
git diff --find-renames=50% -- \
  README.md \
  docs \
  scrapers \
  tools \
  .github \
  .gitignore

python3 tools/validate_ats_discovery_layout.py
```

Review these invariants explicitly:

```bash
jq -r '.name' scrapers/ats-discovery/package.json
jq -r '.compose.service' \
  scrapers/ats-discovery/config/scheduler.example.json

grep -nE '^  ats-discovery:|ehestifter/ats-discovery:local' \
  scrapers/ats-discovery/compose.yaml

grep -RIn --exclude-dir=data --exclude-dir=secrets \
  'foundOn.*ats-discovery' \
  scrapers/ats-discovery/src
```

Expected values:

```text
@ehestifter/ats-discovery
ats-discovery
service: ats-discovery
image: ehestifter/ats-discovery:local
foundOn: ats-discovery
```

The archived milestone intentionally retains planning-time references to `scrapers/career-ops-scan`. Active product files should not.

## 7. Validate active scanner and scheduler configuration

```bash
cd scrapers/ats-discovery

docker compose config --quiet
./ops/scheduler/ats-ops validate-config
./ops/scheduler/ats-ops status
```

Review active local files rather than accepting the mechanical identity update blindly:

```text
config/scanner.local.json
config/scheduler.local.json
compose.yaml
```

At minimum confirm:

- `compose.service` is `ats-discovery`;
- the Compose service key is `ats-discovery`;
- the image is `ehestifter/ats-discovery:local`;
- scanner arguments, import caps, catalog caps, timezone, timer slots, retry policy, paths, and retention values are otherwise unchanged;
- secret paths still resolve under the moved directory.

Do not commit local config, secrets, catalogs, scheduler/tenant state, backups, or run artifacts.

## 8. Run mandatory tests

### Phase 9 package tests

From repository root while the package files are still present:

```bash
python3 -m unittest discover \
  -s phase9-tests \
  -p 'test_*.py' \
  -v
```

Expected:

```text
7 tests
7 passed
```

### Scheduler tests

```bash
cd scrapers/ats-discovery
python3 -m unittest discover \
  -s ops/scheduler/tests \
  -p 'test_*.py' \
  -v
python3 -m compileall -q ops/scheduler ops/systemd
```

Accepted Phase 7 baseline:

```text
27 tests
27 passed
```

### Full scanner suite

```bash
LOCAL_UID="$(id -u)" \
LOCAL_GID="$(id -g)" \
docker compose run --rm \
  --no-deps \
  --entrypoint node \
  ats-discovery \
  --test
```

Accepted pre-Phase-9 baseline:

```text
355 tests
355 pass
0 fail
```

Any scanner or scheduler regression blocks the commit. Phase 9 changes names/docs/migration surfaces only, so a behavioral test failure is not an accepted cleanup side effect.

## 9. Run a bounded offline canary

Use the host wrapper so the normal lock path is exercised:

```bash
./ops/scheduler/ats-ops scanner \
  --label phase9-offline \
  -- \
  scan tracked --offline
```

Inspect the new run:

```bash
latest_run="$(find data/runs -mindepth 1 -maxdepth 1 -type d | sort | tail -1)"
printf 'Latest run: %s\n' "$latest_run"
jq . "$latest_run/summary.json"
```

Confirm:

- the run succeeds or produces a understood degraded exit `2`;
- provider/variant/canary diagnostics remain present;
- no Jobs import occurs in offline mode;
- the new run uses ATS Discovery product identity where emitted;
- old historical run artifacts were not modified.

A bounded live preflight/import can be run after offline validation using the existing operator policy and caps; Phase 9 does not require creating another job.

## 10. Render and inspect replacement systemd units

```bash
mkdir -p /tmp/ehestifter-ats-phase9-units
python3 ops/systemd/install_systemd.py render \
  /tmp/ehestifter-ats-phase9-units \
  --scanner-root "$PWD" \
  --user "$USER"

sed -n '1,220p' \
  /tmp/ehestifter-ats-phase9-units/ehestifter-ats-discovery.service
cat /tmp/ehestifter-ats-phase9-units/*.timer
```

Confirm:

```text
WorkingDirectory=<repository>/scrapers/ats-discovery
Compose service=ats-discovery
User=<normal repository owner>
Timer/retry settings match config/scheduler.local.json
```

## 11. Install and validate the new units

```bash
sudo -E python3 ops/systemd/install_systemd.py install \
  --scanner-root "$PWD"

systemctl list-timers 'ehestifter-ats-*'
systemctl cat ehestifter-ats-discovery.service
systemctl cat ehestifter-ats-catalog-refresh.service
./ops/scheduler/ats-ops status
```

Controlled service canary:

```bash
sudo systemctl start ehestifter-ats-discovery.service
sudo journalctl \
  -u ehestifter-ats-discovery.service \
  -n 200 \
  --no-pager
./ops/scheduler/ats-ops status --json | jq .
```

A normal service start still uses due/idempotency checks. Do not manipulate logical-slot state to force work; use the existing explicit force command only when a deliberate second full run is justified.

## 12. Remove package-only files before committing

The applied repository files are the payload destinations. The package docs, tests, staging payload, and migration script are handoff material and should not be committed unless you deliberately want to retain them elsewhere.

From repository root:

```bash
rm -rf \
  phase9-payload \
  phase9-tests \
  apply_phase9.py \
  APPLY.md \
  CRITICAL-REVIEW.md \
  SOURCES.md \
  TEST-RECORD.md \
  MANIFEST.md
```

Then review and stage:

```bash
git status --short
git add -A
git diff --cached --stat
git diff --cached --find-renames=50%
```

Git detects renames from content similarity; the filesystem migration does not need to invoke `git mv` to preserve history.

Suggested commit message:

```text
scraper: complete ATS Discovery phase 9 cleanup
```

## 13. Rollback before commit

First stop and uninstall any newly installed units:

```bash
sudo systemctl stop \
  ehestifter-ats-discovery.timer \
  ehestifter-ats-catalog-refresh.timer \
  ehestifter-ats-discovery.service \
  ehestifter-ats-catalog-refresh.service \
  2>/dev/null || true

sudo python3 \
  scrapers/ats-discovery/ops/systemd/install_systemd.py \
  uninstall
```

Move the complete local scanner tree back so ignored state/secrets remain together:

```bash
mv scrapers/ats-discovery scrapers/career-ops-scan
```

Restore tracked files from Git:

```bash
git restore --worktree --staged .
```

Reverse the exact product token in ignored active scanner text. Tracked files will also be restored by Git; this loop is primarily for local JSON/YAML/config files:

```bash
python3 - <<'PY'
from pathlib import Path
root = Path('scrapers/career-ops-scan')
excluded = {'data', 'secrets', 'node_modules', '.cache', 'dist'}
for path in root.rglob('*'):
    if not path.is_file() or path.is_symlink():
        continue
    relative = path.relative_to(root)
    if any(part in excluded for part in relative.parts[:-1]):
        continue
    try:
        text = path.read_text(encoding='utf-8')
    except (OSError, UnicodeDecodeError):
        continue
    if 'ats-discovery' in text:
        path.write_text(text.replace('ats-discovery', 'career-ops-scan'), encoding='utf-8')
PY
```

Restore the latest Phase 9 scheduler-state backup when one was created:

```bash
state_dir=scrapers/career-ops-scan/data/state
backup="$(find "$state_dir" -maxdepth 1 \
  -name 'scheduler-state.phase9-pre-rename.*.json' \
  -type f | sort | tail -1)"
if [ -n "$backup" ]; then
  cp -a "$backup" "$state_dir/scheduler-state.json"
fi
```

Remove package-created untracked destinations only after confirming they are not wanted:

```bash
rm -f tools/validate_ats_discovery_layout.py
rm -f docs/archive/milestones/ats-discovery.md
```

Inspect `git status --short` for any renamed active file outside the scanner (for example a workflow whose filename contained the old product token). Git restore recreates the tracked old filename but cannot know whether the new untracked filename should be removed. Delete only the reviewed Phase 9 counterpart; do not use a broad clean command.

Finally reinstall the old units from `scrapers/career-ops-scan` if scheduled operation should resume.

Do not use `git clean -fdx` for rollback: it can delete ignored local configs, catalogs, state, runs, backups, and secrets.
