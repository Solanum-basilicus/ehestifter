# ATS Discovery Phase 9 test record

## Review environment

```text
Python 3.13.5
Git 2.47.3
Linux x86_64, kernel 6.12.13
```

The review container did not have a clone of the private/current working tree and could not resolve GitHub through the shell runtime. Repository structure and completed commits were inspected through GitHub web access; the migration was validated against synthetic repositories containing the relevant tracked/ignored/state/systemd/CI shapes.

## Commands run

```bash
cd ats-discovery-phase9-final

python3 -m compileall -q \
  apply_phase9.py \
  phase9-payload/tools \
  phase9-tests

python3 -m unittest discover \
  -s phase9-tests \
  -p 'test_*.py' \
  -v
```

## Result

```text
test_apply_renames_active_product_and_installs_docs ... ok
test_dry_run_is_non_mutating ... ok
test_git_mode_rewrites_only_tracked_external_references ... ok
test_ignored_local_files_and_historical_runs_are_preserved ... ok
test_payload_manifest_hashes ... ok
test_scheduler_state_path_is_migrated_with_backup_without_outcome_change ... ok
test_second_application_fails_closed ... ok

Ran 7 tests
OK
```

Python compilation completed without errors.

## Coverage of package tests

### Payload integrity

- every complete payload file matches `phase9-payload/payload-manifest.json` SHA-256;
- generated `__pycache__`/`.pyc` files are outside checksum and archive scope;
- payload integrity is checked before repository mutation.

### Dry-run behavior

- required baseline files are checked;
- planned move/rewrite/install operations are reported;
- old scanner tree, root README, and other repository files remain byte-identical.

### Product rename and documentation installation

- complete scanner directory moves to `scrapers/ats-discovery`;
- package name becomes `@ehestifter/ats-discovery`;
- Compose service/image become `ats-discovery` / `ehestifter/ats-discovery:local`;
- active `foundOn` becomes `ats-discovery`;
- active scheduler config service becomes `ats-discovery`;
- root README, master system design, component README, archived milestone, and validator are installed;
- active milestone file is removed;
- bootstrap helper is marked bootstrap-only;
- post-apply layout validation passes.

### Tracked versus untracked repository references

A temporary Git repository was initialized and committed. The migration:

- renamed a tracked `.github/workflows/career-ops-scan.yml` file and its old scanner command/path;
- left an unrelated untracked local note containing the historical branch name byte-identical;
- completed post-apply validation successfully.

### Ignored local content and history preservation

Byte comparisons confirm no changes to:

- `data/runs/<historical-run>/metadata.json` containing former provenance/path values;
- machine-managed catalog data;
- secret files.

The active ignored `config/scheduler.local.json` is intentionally updated because it contains the operational Compose service identity.

### Scheduler-state migration

- old absolute scanner path is replaced in active `scheduler-state.json`;
- one timestamped pre-rename backup is created;
- the existing `completed_degraded` outcome is unchanged;
- historical run state is not rewritten.

### Fail-closed repeat behavior

A second application returns exit `2` because the old source is absent and the canonical destination already exists. The script does not merge or duplicate scanner trees.

## Mandatory executor validation not run here

The full Ehestifter source tree, Docker daemon, host systemd, active local config, and provider network environment were unavailable. The following are therefore required after applying the archive and before commit:

```bash
cd scrapers/ats-discovery

python3 -m unittest discover \
  -s ops/scheduler/tests \
  -p 'test_*.py' \
  -v

python3 -m compileall -q ops/scheduler ops/systemd

LOCAL_UID="$(id -u)" \
LOCAL_GID="$(id -g)" \
docker compose run --rm \
  --no-deps \
  --entrypoint node \
  ats-discovery \
  --test
```

Expected accepted baselines from completed phases:

```text
scheduler: 27 tests passing
scanner:   355 tests passing
```

Also required:

- `docker compose config --quiet`;
- `./ops/scheduler/ats-ops validate-config`;
- bounded wrapper-based offline canary;
- render/inspect/install new systemd units;
- controlled service canary and journal/status inspection;
- Git diff/rename review.

No claim is made that those repository/systemd/Docker validations passed on the review container.
