from __future__ import annotations

import hashlib
import json
from pathlib import Path
import shutil
import subprocess
import sys
import tempfile
import unittest

PACKAGE_ROOT = Path(__file__).resolve().parents[1]
APPLY = PACKAGE_ROOT / "apply_phase9.py"


class Phase9PackageTests(unittest.TestCase):
    def make_repo(self) -> Path:
        root = Path(tempfile.mkdtemp(prefix="phase9-repo-"))
        self.addCleanup(shutil.rmtree, root, True)
        old = root / "scrapers" / "career-ops-scan"
        for relative in [
            "config",
            "src/scan",
            "scripts",
            "ops/scheduler",
            "ops/systemd",
            "data/state",
            "data/runs/historical-run",
            "data/catalogs",
            "secrets",
        ]:
            (old / relative).mkdir(parents=True, exist_ok=True)

        (root / ".gitignore").write_text(
            "scrapers/career-ops-scan/config/*.local.json\n"
            "scrapers/career-ops-scan/data/\n"
            "scrapers/career-ops-scan/secrets/\n",
            encoding="utf-8",
        )
        (root / "docs").mkdir(parents=True)
        (root / ".github/workflows").mkdir(parents=True)
        (root / ".github/workflows/career-ops-scan.yml").write_text(
            "run: cd scrapers/career-ops-scan && docker compose run career-ops-scan\n",
            encoding="utf-8",
        )
        (root / "docs/system-design.md").write_text("old system design\n", encoding="utf-8")
        (root / "docs/milestone_ats_discovery.md").write_text("active milestone\n", encoding="utf-8")
        (root / "README.md").write_text("old readme\n", encoding="utf-8")

        (old / "package.json").write_text(
            json.dumps({"name": "@ehestifter/career-ops-scan"}, indent=2) + "\n",
            encoding="utf-8",
        )
        (old / "compose.yaml").write_text(
            "services:\n"
            "  career-ops-scan:\n"
            "    image: ehestifter/career-ops-scan:local\n",
            encoding="utf-8",
        )
        scheduler = {"compose": {"service": "career-ops-scan"}}
        (old / "config/scheduler.example.json").write_text(
            json.dumps(scheduler, indent=2) + "\n", encoding="utf-8"
        )
        (old / "config/scheduler.local.json").write_text(
            json.dumps(scheduler, indent=2) + "\n", encoding="utf-8"
        )
        (old / "src/scan/tracked-source.mjs").write_text(
            "export const item = { foundOn: 'career-ops-scan' };\n",
            encoding="utf-8",
        )
        bootstrap = old / "scripts/copy-upstream-providers.sh"
        bootstrap.write_text(
            "#!/usr/bin/env bash\n# source: https://github.com/santifer/career-ops\n",
            encoding="utf-8",
        )
        bootstrap.chmod(0o755)
        (old / "UPSTREAM.md").write_text(
            "Selected provider source: santifer/career-ops (MIT).\n",
            encoding="utf-8",
        )
        (old / "ops/scheduler/ats_scheduler.py").write_text(
            "# career-ops-scan scheduler\n", encoding="utf-8"
        )
        (old / "ops/systemd/install_systemd.py").write_text(
            "# career-ops-scan installer\n", encoding="utf-8"
        )
        (old / "ops/systemd/ehestifter-ats-discovery.service.in").write_text(
            "[Service]\nWorkingDirectory=/tmp/career-ops-scan\n",
            encoding="utf-8",
        )
        (old / "ops/systemd/ehestifter-ats-discovery.timer").write_text(
            "[Timer]\nPersistent=true\n", encoding="utf-8"
        )

        old_abs = str(old.resolve())
        (old / "data/state/scheduler-state.json").write_text(
            json.dumps(
                {
                    "schemaVersion": 1,
                    "lastRunPath": old_abs + "/data/runs/latest",
                    "outcome": "completed_degraded",
                },
                indent=2,
            )
            + "\n",
            encoding="utf-8",
        )
        (old / "data/runs/historical-run/metadata.json").write_text(
            json.dumps({"foundOn": "career-ops-scan", "root": old_abs}) + "\n",
            encoding="utf-8",
        )
        (old / "data/catalogs/ashby.json").write_bytes(b'{"provider":"ashby"}\n')
        (old / "secrets/jobs-key").write_text("career-ops-scan-secret-is-opaque\n", encoding="utf-8")
        return root

    def run_apply(self, repo: Path, *extra: str) -> subprocess.CompletedProcess[str]:
        return subprocess.run(
            [
                sys.executable,
                str(APPLY),
                "--repo-root",
                str(repo),
                "--allow-unverified-head",
                "--skip-systemd-check",
                *extra,
            ],
            text=True,
            stdout=subprocess.PIPE,
            stderr=subprocess.PIPE,
        )

    def test_payload_manifest_hashes(self) -> None:
        manifest_path = PACKAGE_ROOT / "phase9-payload/payload-manifest.json"
        manifest = json.loads(manifest_path.read_text(encoding="utf-8"))
        self.assertGreaterEqual(len(manifest), 5)
        for relative, expected in manifest.items():
            actual = hashlib.sha256(
                (PACKAGE_ROOT / "phase9-payload" / relative).read_bytes()
            ).hexdigest()
            self.assertEqual(expected, actual, relative)

    def test_dry_run_is_non_mutating(self) -> None:
        repo = self.make_repo()
        before = (repo / "scrapers/career-ops-scan/compose.yaml").read_bytes()
        result = self.run_apply(repo, "--dry-run")
        self.assertEqual(0, result.returncode, result.stderr)
        self.assertTrue((repo / "scrapers/career-ops-scan").is_dir())
        self.assertFalse((repo / "scrapers/ats-discovery").exists())
        self.assertEqual(before, (repo / "scrapers/career-ops-scan/compose.yaml").read_bytes())
        self.assertEqual("old readme\n", (repo / "README.md").read_text(encoding="utf-8"))

    def test_apply_renames_active_product_and_installs_docs(self) -> None:
        repo = self.make_repo()
        result = self.run_apply(repo)
        self.assertEqual(0, result.returncode, result.stderr + result.stdout)
        new = repo / "scrapers/ats-discovery"
        self.assertTrue(new.is_dir())
        self.assertFalse((repo / "scrapers/career-ops-scan").exists())
        self.assertIn("ats-discovery:", (new / "compose.yaml").read_text(encoding="utf-8"))
        self.assertIn("@ehestifter/ats-discovery", (new / "package.json").read_text(encoding="utf-8"))
        self.assertIn("foundOn: 'ats-discovery'", (new / "src/scan/tracked-source.mjs").read_text(encoding="utf-8"))
        self.assertEqual(
            "ats-discovery",
            json.loads((new / "config/scheduler.local.json").read_text(encoding="utf-8"))["compose"]["service"],
        )
        self.assertIn("ATS-DISCOVERY-BOOTSTRAP-ONLY", (new / "scripts/copy-upstream-providers.sh").read_text(encoding="utf-8"))
        self.assertIn("## 14. ATS Discovery", (repo / "docs/system-design.md").read_text(encoding="utf-8"))
        self.assertTrue((repo / "docs/archive/milestones/ats-discovery.md").is_file())
        self.assertFalse((repo / "docs/milestone_ats_discovery.md").exists())
        self.assertTrue((repo / "tools/validate_ats_discovery_layout.py").is_file())
        workflow = repo / ".github/workflows/ats-discovery.yml"
        self.assertTrue(workflow.is_file())
        self.assertNotIn("career-ops-scan", workflow.read_text(encoding="utf-8"))
        self.assertIn("scrapers/ats-discovery", workflow.read_text(encoding="utf-8"))

    def test_ignored_local_files_and_historical_runs_are_preserved(self) -> None:
        repo = self.make_repo()
        old = repo / "scrapers/career-ops-scan"
        historical_before = (old / "data/runs/historical-run/metadata.json").read_bytes()
        secret_before = (old / "secrets/jobs-key").read_bytes()
        catalog_before = (old / "data/catalogs/ashby.json").read_bytes()
        result = self.run_apply(repo)
        self.assertEqual(0, result.returncode, result.stderr + result.stdout)
        new = repo / "scrapers/ats-discovery"
        self.assertEqual(historical_before, (new / "data/runs/historical-run/metadata.json").read_bytes())
        self.assertEqual(secret_before, (new / "secrets/jobs-key").read_bytes())
        self.assertEqual(catalog_before, (new / "data/catalogs/ashby.json").read_bytes())

    def test_scheduler_state_path_is_migrated_with_backup_without_outcome_change(self) -> None:
        repo = self.make_repo()
        result = self.run_apply(repo)
        self.assertEqual(0, result.returncode, result.stderr + result.stdout)
        state_dir = repo / "scrapers/ats-discovery/data/state"
        state = json.loads((state_dir / "scheduler-state.json").read_text(encoding="utf-8"))
        self.assertIn("/scrapers/ats-discovery/", state["lastRunPath"])
        self.assertEqual("completed_degraded", state["outcome"])
        backups = list(state_dir.glob("scheduler-state.phase9-pre-rename.*.json"))
        self.assertEqual(1, len(backups))
        old_state = json.loads(backups[0].read_text(encoding="utf-8"))
        self.assertIn("/scrapers/career-ops-scan/", old_state["lastRunPath"])


    def test_git_mode_rewrites_only_tracked_external_references(self) -> None:
        repo = self.make_repo()
        subprocess.run(["git", "init", "-q"], cwd=repo, check=True)
        subprocess.run(["git", "config", "user.email", "phase9@example.invalid"], cwd=repo, check=True)
        subprocess.run(["git", "config", "user.name", "Phase 9 Test"], cwd=repo, check=True)
        subprocess.run(["git", "add", "."], cwd=repo, check=True)
        subprocess.run(["git", "commit", "-qm", "phase7 fixture"], cwd=repo, check=True)
        untracked = repo / "local-notes.txt"
        untracked.write_text("feature/career-ops-scan is a historical branch note\n", encoding="utf-8")

        result = self.run_apply(repo)
        self.assertEqual(0, result.returncode, result.stderr + result.stdout)
        self.assertEqual(
            "feature/career-ops-scan is a historical branch note\n",
            untracked.read_text(encoding="utf-8"),
        )
        workflow = repo / ".github/workflows/ats-discovery.yml"
        self.assertTrue(workflow.is_file())
        self.assertNotIn("career-ops-scan", workflow.read_text(encoding="utf-8"))

    def test_second_application_fails_closed(self) -> None:
        repo = self.make_repo()
        first = self.run_apply(repo)
        self.assertEqual(0, first.returncode, first.stderr + first.stdout)
        second = self.run_apply(repo)
        self.assertEqual(2, second.returncode)
        self.assertIn("already", second.stderr.lower())


if __name__ == "__main__":
    unittest.main(verbosity=2)
