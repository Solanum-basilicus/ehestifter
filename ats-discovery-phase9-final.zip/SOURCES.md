# ATS Discovery Phase 9 sources

Phase 9 is primarily an integration and cleanup change. No third-party code was copied into the migration, validator, or documentation payload.

## Ehestifter sources reviewed

- Current master architecture source supplied for this phase: `system-design.md`.
- Active ATS Discovery milestone source supplied for this phase: `milestone_ats_discovery(3).md`.
- Repository: <https://github.com/Solanum-basilicus/ehestifter>
- Working branch: <https://github.com/Solanum-basilicus/ehestifter/tree/feature/career-ops-scan>
- Completed Phase 7 commit: <https://github.com/Solanum-basilicus/ehestifter/commit/9f8452c8e1e8dbe5a778abb090da9c28a110890f>
- Branch commit history used to confirm completed Phase 5B, Phase 6, and Phase 7 ordering: <https://github.com/Solanum-basilicus/ehestifter/commits/feature/career-ops-scan/>

Repository surfaces inspected included the root README, active milestone document, scanner Compose/package identity, Phase 6 commits, and Phase 7 scheduler files/commit summary.

## Upstream attribution retained by the milestone

- Career-Ops repository: <https://github.com/santifer/career-ops>
- Career-Ops initial extraction release: <https://github.com/santifer/career-ops/releases/tag/career-ops-v1.20.0>
- job-board-aggregator repository: <https://github.com/Feashliaa/job-board-aggregator>
- job-board-aggregator tenant catalogs: <https://github.com/Feashliaa/job-board-aggregator/tree/main/data>
- job-board-aggregator license: <https://github.com/Feashliaa/job-board-aggregator/blob/main/LICENSE>

Phase 9 preserves these references and the scanner's existing per-provider/catalog pinned source records. `Career-Ops` remains an upstream/source name; `ATS Discovery` is the Ehestifter product name.

## Primary operational references

- systemd service unit settings, including `WorkingDirectory=`: <https://www.freedesktop.org/software/systemd/man/latest/systemd.service.html>
- systemd timer behavior, including persistent timers: <https://www.freedesktop.org/software/systemd/man/latest/systemd.timer.html>
- Docker Compose service definitions and service-name keys: <https://docs.docker.com/reference/compose-file/services/>
- Git directory/file moves: <https://git-scm.com/docs/git-mv>
- Git rename detection explanation: <https://git-scm.com/book/en/v2/Git-Basics-Recording-Changes-to-the-Repository>

These references support the operational conclusions that rendered units must be replaced after a path/service rename, Compose service keys are active command identities, and Git can recognize filesystem moves as renames from content similarity.

## Deferred issue links retained

- Ehestifter issue #1 — richer location normalization/evidence: <https://github.com/Solanum-basilicus/ehestifter/issues/1>
- Ehestifter issue #2 — SuccessFactors CSB Jobs canonical identity: <https://github.com/Solanum-basilicus/ehestifter/issues/2>
- Ehestifter issue #3 — unsupported provider ingestion: <https://github.com/Solanum-basilicus/ehestifter/issues/3>
- Ehestifter issue #4 — missing provider tenant catalogs: <https://github.com/Solanum-basilicus/ehestifter/issues/4>

## Source-use statement

- The canonical `docs/system-design.md` payload is a transformed and expanded version of the supplied Ehestifter system design.
- The archived milestone payload preserves the supplied milestone's sections 1–13, adds an archival header and final implementation outcome, and retains its references.
- The root/component READMEs, migration, validator, package tests, apply guide, critical review, and test record are original Phase 9 material.
- No external article text or third-party implementation was copied into Phase 9.
