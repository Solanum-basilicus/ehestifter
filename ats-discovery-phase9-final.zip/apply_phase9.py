#!/usr/bin/env python3
"""Apply ATS Discovery Phase 9 from the Ehestifter repository root.

The migration deliberately moves the complete scanner directory so ignored local
configuration, catalogs, state, secrets, and run artifacts remain in place. It
then rewrites only active scanner text outside data/secrets and installs the
reviewed documentation payload.
"""

from __future__ import annotations

import argparse
import hashlib
import json
import os
from pathlib import Path
import shutil
import subprocess
import sys
import tempfile
from datetime import datetime, timezone
from typing import Any, Iterable

PHASE7_COMMIT = "9f8452c8e1e8dbe5a778abb090da9c28a110890f"
OLD_REL = Path("scrapers/career-ops-scan")
NEW_REL = Path("scrapers/ats-discovery")
OLD_TOKEN = "career-ops-scan"
NEW_TOKEN = "ats-discovery"
OLD_MILESTONE = Path("docs/milestone_ats_discovery.md")
ARCHIVED_MILESTONE = Path("docs/archive/milestones/ats-discovery.md")
BOOTSTRAP_MARKER = "ATS-DISCOVERY-BOOTSTRAP-ONLY"
PAYLOAD_MANIFEST = "payload-manifest.json"

EXCLUDED_REWRITE_DIRS = {
    ".git",
    ".cache",
    "data",
    "dist",
    "node_modules",
    "secrets",
}

REPOSITORY_EXCLUDED_DIRS = {
    ".cache",
    ".git",
    ".idea",
    ".mypy_cache",
    ".pytest_cache",
    ".ruff_cache",
    ".tox",
    ".venv",
    ".vscode",
    "__pycache__",
    "build",
    "coverage",
    "dist",
    "htmlcov",
    "node_modules",
    "venv",
}

PACKAGE_ARTIFACT_NAMES = {
    "APPLY.md",
    "CRITICAL-REVIEW.md",
    "MANIFEST.md",
    "SOURCES.md",
    "TEST-RECORD.md",
    "apply_phase9.py",
    "phase9-payload",
    "phase9-tests",
}

TEXT_SUFFIXES = {
    "",
    ".cjs",
    ".env",
    ".example",
    ".in",
    ".js",
    ".json",
    ".lock",
    ".md",
    ".mjs",
    ".py",
    ".service",
    ".sh",
    ".timer",
    ".txt",
    ".yaml",
    ".yml",
}


class Phase9Error(RuntimeError):
    """Expected, operator-actionable migration failure."""


def parse_args(argv: list[str] | None = None) -> argparse.Namespace:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument(
        "--repo-root",
        default=".",
        help="Ehestifter repository root (default: current directory).",
    )
    parser.add_argument(
        "--dry-run",
        action="store_true",
        help="Perform all preflight checks and print planned changes only.",
    )
    parser.add_argument(
        "--allow-unverified-head",
        action="store_true",
        help="Allow application when the Phase 7 commit cannot be verified as an ancestor.",
    )
    parser.add_argument(
        "--allow-dirty",
        action="store_true",
        help="Allow tracked working-tree changes. Untracked archive files do not count as dirty.",
    )
    parser.add_argument(
        "--skip-systemd-check",
        action="store_true",
        help="Skip the installed/active ehestifter-ats unit safety check (intended for tests only).",
    )
    return parser.parse_args(argv)


def run(command: list[str], cwd: Path, check: bool = False) -> subprocess.CompletedProcess[str]:
    return subprocess.run(
        command,
        cwd=cwd,
        text=True,
        stdout=subprocess.PIPE,
        stderr=subprocess.PIPE,
        check=check,
    )


def is_git_repo(repo_root: Path) -> bool:
    return run(["git", "rev-parse", "--is-inside-work-tree"], repo_root).returncode == 0


def verify_git_state(repo_root: Path, allow_unverified_head: bool, allow_dirty: bool) -> None:
    if not is_git_repo(repo_root):
        if allow_unverified_head:
            return
        raise Phase9Error(
            "Repository Git metadata is unavailable. Re-run from the Ehestifter clone, "
            "or use --allow-unverified-head only after manually verifying the Phase 7 baseline."
        )

    if not allow_dirty:
        status = run(
            ["git", "status", "--porcelain", "--untracked-files=no"],
            repo_root,
        )
        if status.returncode != 0:
            raise Phase9Error(f"Unable to inspect Git status: {status.stderr.strip()}")
        if status.stdout.strip():
            raise Phase9Error(
                "Tracked working-tree changes are present. Commit/stash them first, or use "
                "--allow-dirty after reviewing the collision risk."
            )

    ancestor = run(
        ["git", "merge-base", "--is-ancestor", PHASE7_COMMIT, "HEAD"],
        repo_root,
    )
    if ancestor.returncode != 0 and not allow_unverified_head:
        raise Phase9Error(
            f"Phase 7 commit {PHASE7_COMMIT} is not verified as an ancestor of HEAD. "
            "Apply Phase 9 to the completed Phase 7 branch or pass --allow-unverified-head "
            "only after manual review."
        )


def installed_systemd_units() -> list[Path]:
    unit_dirs = [Path("/etc/systemd/system"), Path("/usr/local/lib/systemd/system")]
    found: list[Path] = []
    for unit_dir in unit_dirs:
        if not unit_dir.exists():
            continue
        found.extend(sorted(unit_dir.glob("ehestifter-ats-*")))
    return [path for path in found if path.is_file() or path.is_symlink()]


def active_systemd_units() -> list[str]:
    if shutil.which("systemctl") is None:
        return []
    active: list[str] = []
    names = [
        "ehestifter-ats-discovery.timer",
        "ehestifter-ats-discovery.service",
        "ehestifter-ats-catalog-refresh.timer",
        "ehestifter-ats-catalog-refresh.service",
    ]
    for name in names:
        result = subprocess.run(
            ["systemctl", "is-active", "--quiet", name],
            stdout=subprocess.DEVNULL,
            stderr=subprocess.DEVNULL,
        )
        if result.returncode == 0:
            active.append(name)
    return active


def verify_systemd_safety(skip: bool) -> None:
    if skip:
        return
    active = active_systemd_units()
    installed = installed_systemd_units()
    if active or installed:
        details: list[str] = []
        if active:
            details.append("active: " + ", ".join(active))
        if installed:
            details.append("installed: " + ", ".join(str(path) for path in installed))
        raise Phase9Error(
            "Old scheduler units must be stopped and uninstalled before the directory rename "
            "because their rendered WorkingDirectory points at the old path ("
            + "; ".join(details)
            + "). Follow APPLY.md, then retry."
        )


def sha256(path: Path) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as handle:
        for chunk in iter(lambda: handle.read(1024 * 1024), b""):
            digest.update(chunk)
    return digest.hexdigest()


def load_payload_manifest(payload_root: Path) -> dict[str, str]:
    manifest_path = payload_root / PAYLOAD_MANIFEST
    if not manifest_path.is_file():
        raise Phase9Error(f"Missing payload manifest: {manifest_path}")
    try:
        raw = json.loads(manifest_path.read_text(encoding="utf-8"))
    except (OSError, json.JSONDecodeError) as exc:
        raise Phase9Error(f"Invalid payload manifest: {exc}") from exc
    if not isinstance(raw, dict) or not raw:
        raise Phase9Error("Payload manifest must be a non-empty object of path -> SHA-256.")
    result: dict[str, str] = {}
    for rel, expected in raw.items():
        if not isinstance(rel, str) or not isinstance(expected, str):
            raise Phase9Error("Payload manifest contains a non-string path or checksum.")
        result[rel] = expected
    return result


def verify_payload(payload_root: Path) -> dict[str, str]:
    manifest = load_payload_manifest(payload_root)
    for rel, expected in sorted(manifest.items()):
        path = payload_root / rel
        if not path.is_file():
            raise Phase9Error(f"Payload file is missing: {rel}")
        actual = sha256(path)
        if actual != expected:
            raise Phase9Error(
                f"Payload checksum mismatch for {rel}: expected {expected}, got {actual}"
            )
    return manifest


def ensure_layout(repo_root: Path) -> None:
    old_path = repo_root / OLD_REL
    new_path = repo_root / NEW_REL
    if not old_path.is_dir():
        if new_path.exists():
            raise Phase9Error(
                f"{NEW_REL} already exists while {OLD_REL} is absent; Phase 9 appears already "
                "applied or partially applied. Run the validator and inspect Git status."
            )
        raise Phase9Error(f"Expected completed scanner directory is missing: {OLD_REL}")
    if new_path.exists():
        raise Phase9Error(
            f"Destination already exists: {NEW_REL}. Refusing to merge two scanner trees."
        )
    required = [
        old_path / "compose.yaml",
        old_path / "package.json",
        old_path / "ops" / "systemd" / "install_systemd.py",
        old_path / "ops" / "scheduler" / "ats_scheduler.py",
    ]
    missing = [str(path.relative_to(repo_root)) for path in required if not path.is_file()]
    if missing:
        raise Phase9Error("Phase 7 baseline files are missing: " + ", ".join(missing))


def should_rewrite(path: Path, scanner_root: Path) -> bool:
    try:
        relative = path.relative_to(scanner_root)
    except ValueError:
        return False
    if any(part in EXCLUDED_REWRITE_DIRS for part in relative.parts[:-1]):
        return False
    if path.is_symlink() or not path.is_file():
        return False
    if path.suffix.lower() not in TEXT_SUFFIXES:
        return False
    try:
        if path.stat().st_size > 4 * 1024 * 1024:
            return False
        sample = path.read_bytes()[:8192]
    except OSError:
        return False
    return b"\x00" not in sample


def rewrite_file(path: Path, old: str, new: str, dry_run: bool) -> bool:
    try:
        text = path.read_text(encoding="utf-8")
    except (OSError, UnicodeDecodeError):
        return False
    if old not in text:
        return False
    if not dry_run:
        mode = path.stat().st_mode
        temporary = path.with_name(path.name + ".phase9-tmp")
        temporary.write_text(text.replace(old, new), encoding="utf-8")
        os.chmod(temporary, mode)
        os.replace(temporary, path)
    return True


def rewrite_scanner_tree(scanner_root: Path, dry_run: bool) -> list[Path]:
    changed: list[Path] = []
    for path in sorted(scanner_root.rglob("*")):
        if should_rewrite(path, scanner_root) and rewrite_file(
            path, OLD_TOKEN, NEW_TOKEN, dry_run
        ):
            changed.append(path)

    rename_candidates = sorted(
        (
            path
            for path in scanner_root.rglob("*")
            if OLD_TOKEN in path.name
            and not any(part in EXCLUDED_REWRITE_DIRS for part in path.relative_to(scanner_root).parts)
        ),
        key=lambda path: len(path.parts),
        reverse=True,
    )
    for path in rename_candidates:
        destination = path.with_name(path.name.replace(OLD_TOKEN, NEW_TOKEN))
        if destination.exists():
            raise Phase9Error(f"Cannot rename {path}: destination exists: {destination}")
        if not dry_run:
            path.rename(destination)
        changed.append(destination)
    return changed


def repository_candidate_paths(repo_root: Path) -> list[Path]:
    """Prefer tracked files; fall back to a bounded filesystem walk for test fixtures."""
    if is_git_repo(repo_root):
        result = subprocess.run(
            ["git", "ls-files", "-z"],
            cwd=repo_root,
            stdout=subprocess.PIPE,
            stderr=subprocess.PIPE,
        )
        if result.returncode != 0:
            raise Phase9Error(
                "Unable to enumerate tracked repository files: "
                + result.stderr.decode("utf-8", errors="replace").strip()
            )
        return [repo_root / item.decode("utf-8") for item in result.stdout.split(b"\0") if item]

    candidates: list[Path] = []
    for path in repo_root.rglob("*"):
        relative = path.relative_to(repo_root)
        if any(part in REPOSITORY_EXCLUDED_DIRS for part in relative.parts):
            continue
        candidates.append(path)
    return candidates


def should_rewrite_repository_path(path: Path, repo_root: Path) -> bool:
    try:
        relative = path.relative_to(repo_root)
    except ValueError:
        return False
    if not relative.parts:
        return False
    if relative.parts[0] in PACKAGE_ARTIFACT_NAMES:
        return False
    if any(part in REPOSITORY_EXCLUDED_DIRS for part in relative.parts):
        return False
    if len(relative.parts) >= 2 and relative.parts[0] == "docs" and relative.parts[1] == "archive":
        return False
    if relative.is_relative_to(NEW_REL):
        return False
    if path.is_symlink() or not path.is_file() or path.suffix.lower() not in TEXT_SUFFIXES:
        return False
    try:
        if path.stat().st_size > 4 * 1024 * 1024:
            return False
        sample = path.read_bytes()[:8192]
    except OSError:
        return False
    return b"\x00" not in sample


def rewrite_repository_references(repo_root: Path, dry_run: bool) -> list[Path]:
    """Rewrite active references outside the scanner, while preserving archives/package files."""
    changed: list[Path] = []
    candidates = repository_candidate_paths(repo_root)
    for path in sorted(candidates):
        if should_rewrite_repository_path(path, repo_root) and rewrite_file(
            path, OLD_TOKEN, NEW_TOKEN, dry_run
        ):
            changed.append(path)

    rename_candidates = sorted(
        (
            path
            for path in candidates
            if OLD_TOKEN in path.name
            and path.exists()
            and not path.is_symlink()
            and path.relative_to(repo_root).parts[0] not in PACKAGE_ARTIFACT_NAMES
            and not any(
                part in REPOSITORY_EXCLUDED_DIRS
                for part in path.relative_to(repo_root).parts
            )
            and not (
                len(path.relative_to(repo_root).parts) >= 2
                and path.relative_to(repo_root).parts[0] == "docs"
                and path.relative_to(repo_root).parts[1] == "archive"
            )
            and not path.relative_to(repo_root).is_relative_to(NEW_REL)
        ),
        key=lambda path: len(path.parts),
        reverse=True,
    )
    for path in rename_candidates:
        destination = path.with_name(path.name.replace(OLD_TOKEN, NEW_TOKEN))
        if destination.exists():
            raise Phase9Error(f"Cannot rename active repository path {path}: {destination} exists")
        if not dry_run:
            path.rename(destination)
        changed.append(destination)
    return changed


def atomic_write_text(path: Path, text: str, mode: int | None = None) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    fd, temp_name = tempfile.mkstemp(prefix=path.name + ".", dir=path.parent)
    temp = Path(temp_name)
    try:
        with os.fdopen(fd, "w", encoding="utf-8", newline="") as handle:
            handle.write(text)
            handle.flush()
            os.fsync(handle.fileno())
        if mode is not None:
            os.chmod(temp, mode)
        os.replace(temp, path)
    finally:
        temp.unlink(missing_ok=True)


def copy_payload(payload_root: Path, repo_root: Path, manifest: dict[str, str], dry_run: bool) -> list[Path]:
    changed: list[Path] = []
    for rel in sorted(manifest):
        source = payload_root / rel
        destination = repo_root / rel
        changed.append(destination)
        if dry_run:
            continue
        mode = source.stat().st_mode
        atomic_write_text(destination, source.read_text(encoding="utf-8"), mode=mode)
    return changed


def update_gitignore(repo_root: Path, dry_run: bool) -> bool:
    path = repo_root / ".gitignore"
    if not path.is_file():
        raise Phase9Error("Repository .gitignore is missing.")
    text = path.read_text(encoding="utf-8")
    updated = text.replace(str(OLD_REL), str(NEW_REL))
    if text == updated:
        # It is acceptable for the repo not to have scanner-specific ignore rules.
        return False
    if not dry_run:
        atomic_write_text(path, updated, mode=path.stat().st_mode)
    return True


def add_bootstrap_marker(scanner_root: Path, dry_run: bool) -> bool:
    path = scanner_root / "scripts" / "copy-upstream-providers.sh"
    if not path.is_file():
        raise Phase9Error(f"Expected bootstrap helper is missing: {path}")
    text = path.read_text(encoding="utf-8")
    if BOOTSTRAP_MARKER in text:
        return False
    warning = (
        f"# {BOOTSTRAP_MARKER}\n"
        "# Bootstrap/reproducibility helper only. It may overwrite adapted provider files.\n"
        "# Do not use it as an unattended upstream-update mechanism; inspect and test diffs.\n"
    )
    if text.startswith("#!"):
        newline = text.find("\n")
        if newline == -1:
            updated = text + "\n" + warning
        else:
            updated = text[: newline + 1] + warning + text[newline + 1 :]
    else:
        updated = warning + text
    if not dry_run:
        atomic_write_text(path, updated, mode=path.stat().st_mode)
    return True


def replace_paths(value: Any, replacements: list[tuple[str, str]]) -> tuple[Any, bool]:
    changed = False
    if isinstance(value, str):
        updated = value
        for old, new in replacements:
            updated = updated.replace(old, new)
        return updated, updated != value
    if isinstance(value, list):
        result: list[Any] = []
        for item in value:
            new_item, item_changed = replace_paths(item, replacements)
            result.append(new_item)
            changed = changed or item_changed
        return result, changed
    if isinstance(value, dict):
        result_dict: dict[Any, Any] = {}
        for key, item in value.items():
            new_item, item_changed = replace_paths(item, replacements)
            result_dict[key] = new_item
            changed = changed or item_changed
        return result_dict, changed
    return value, False


def migrate_scheduler_state(repo_root: Path, dry_run: bool) -> tuple[bool, Path | None]:
    state_path = repo_root / NEW_REL / "data" / "state" / "scheduler-state.json"
    if not state_path.is_file():
        return False, None
    try:
        data = json.loads(state_path.read_text(encoding="utf-8"))
    except (OSError, json.JSONDecodeError) as exc:
        raise Phase9Error(
            f"Scheduler state is unreadable after the move; refusing to guess: {state_path}: {exc}"
        ) from exc

    old_abs = str((repo_root / OLD_REL).resolve())
    new_abs = str((repo_root / NEW_REL).resolve())
    replacements = [
        (old_abs, new_abs),
        (str(OLD_REL), str(NEW_REL)),
    ]
    updated, changed = replace_paths(data, replacements)
    if not changed:
        return False, None

    timestamp = datetime.now(timezone.utc).strftime("%Y%m%dT%H%M%SZ")
    backup = state_path.with_name(f"scheduler-state.phase9-pre-rename.{timestamp}.json")
    if not dry_run:
        if backup.exists():
            raise Phase9Error(f"Scheduler-state backup already exists: {backup}")
        shutil.copy2(state_path, backup)
        serialized = json.dumps(updated, indent=2, sort_keys=True) + "\n"
        atomic_write_text(state_path, serialized, mode=state_path.stat().st_mode)
    return True, backup


def remove_old_milestone(repo_root: Path, dry_run: bool) -> bool:
    path = repo_root / OLD_MILESTONE
    if not path.exists():
        return False
    if path.is_dir():
        raise Phase9Error(f"Expected milestone file is a directory: {path}")
    if not dry_run:
        path.unlink()
    return True


def validate(repo_root: Path) -> None:
    validator = repo_root / "tools" / "validate_ats_discovery_layout.py"
    result = run([sys.executable, str(validator), "--repo-root", str(repo_root)], repo_root)
    if result.stdout:
        print(result.stdout, end="")
    if result.returncode != 0:
        raise Phase9Error(
            "Post-apply layout validation failed. Inspect the errors above and Git diff; "
            f"validator stderr: {result.stderr.strip()}"
        )


def relative_display(path: Path, repo_root: Path) -> str:
    try:
        return str(path.relative_to(repo_root))
    except ValueError:
        return str(path)


def apply(args: argparse.Namespace) -> int:
    repo_root = Path(args.repo_root).expanduser().resolve()
    package_root = Path(__file__).resolve().parent
    payload_root = package_root / "phase9-payload"

    if not repo_root.is_dir():
        raise Phase9Error(f"Repository root does not exist: {repo_root}")

    print(f"Phase 9 repository root: {repo_root}")
    verify_payload(payload_root)
    verify_git_state(repo_root, args.allow_unverified_head, args.allow_dirty)
    verify_systemd_safety(args.skip_systemd_check)
    ensure_layout(repo_root)

    manifest = load_payload_manifest(payload_root)
    old_path = repo_root / OLD_REL
    new_path = repo_root / NEW_REL

    if args.dry_run:
        print(f"DRY RUN: move {OLD_REL} -> {NEW_REL}")
    else:
        old_path.rename(new_path)
        print(f"Moved {OLD_REL} -> {NEW_REL}")

    rewrite_root = old_path if args.dry_run else new_path
    rewritten = rewrite_scanner_tree(rewrite_root, args.dry_run)
    print(f"{'Would rewrite' if args.dry_run else 'Rewrote'} {len(rewritten)} scanner paths/files.")

    external_references = rewrite_repository_references(repo_root, args.dry_run)
    print(
        f"{'Would rewrite' if args.dry_run else 'Rewrote'} "
        f"{len(external_references)} active repository references outside the scanner."
    )

    if add_bootstrap_marker(rewrite_root, args.dry_run):
        print("Marked copy-upstream-providers.sh as bootstrap-only.")

    if update_gitignore(repo_root, args.dry_run):
        print("Updated scanner paths in .gitignore.")

    # Scheduler state is only reachable at the destination after the real move.
    if args.dry_run:
        state_path = old_path / "data" / "state" / "scheduler-state.json"
        if state_path.is_file():
            print("DRY RUN: inspect/migrate active scheduler-state path strings with backup.")
    else:
        state_changed, backup = migrate_scheduler_state(repo_root, dry_run=False)
        if state_changed:
            print(
                "Migrated active scheduler-state path strings; backup: "
                + relative_display(backup, repo_root)  # type: ignore[arg-type]
            )

    copied = copy_payload(payload_root, repo_root, manifest, args.dry_run)
    print(f"{'Would install' if args.dry_run else 'Installed'} {len(copied)} payload files.")

    if remove_old_milestone(repo_root, args.dry_run):
        print(f"{'Would remove' if args.dry_run else 'Removed'} active milestone file: {OLD_MILESTONE}")

    if args.dry_run:
        print("Dry run completed; no repository files were changed.")
        return 0

    validate(repo_root)
    print("Phase 9 migration and post-apply layout validation completed.")
    print("Next: run the Docker scanner suite and scheduler tests from APPLY.md before committing.")
    return 0


def main(argv: list[str] | None = None) -> int:
    try:
        return apply(parse_args(argv))
    except Phase9Error as exc:
        print(f"ERROR: {exc}", file=sys.stderr)
        return 2
    except KeyboardInterrupt:
        print("ERROR: interrupted; inspect Git status before retrying.", file=sys.stderr)
        return 130


if __name__ == "__main__":
    raise SystemExit(main())
